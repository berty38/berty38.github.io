This documentation will be very incomplete. I hope to improve it over time. Please send questions to bert@cs.umd.edu, or just email me when you download it and give me a quick description of what you're doing with it and I can help you out. 

First, at least skim the paper http://arxiv.org/abs/0908.1769 to have an idea of what this code does.

The most relevant files in this directory are

estper.c - the c program that reads in a matrix. This version uses the speedups described in the arxiv paper which have problems when entries in the input matrix are zero (since the speedup techniques divide by some entries of the matrix).
estper.m - MATLAB wrapper for computing the Bethe approximation of the permanent. This function writes the MATLAB input to a file and calls the estper.c executable, which must be compiled to the program "estper" and placed in the current directory. 
estperslow.m - Fully matlab implementation of the algorithm. As the name implies, this is much slower. This version does not use the speedups so it can handle zero-entries.

The other files in this directory are:

bethe.m - MATLAB function for computing the bethe energy, entropy, and the free energy of a graphical model from makebmatchexpanded
bp.m - runs belief propagation on the graphical model from makebmatchexpanded
makebmatchexpanded.m - creates a graphical model object representing the b-matching problem
makegraph.m - creates a graphical model.
safelog.m - nan friendly log function
safeplus.m - nan friendly adder



Again, apologies for how poorly maintained this code is. I'm still very interested in this project and I would be very happy to work with you on anything you want to do with this code, so please do not hesitate to contact me if you need help.