mex -largeArrayDims spouterprod.c
mex -largeArrayDims sprowcolsum.c
mex -largeArrayDims sprowsumprod.c

