/*
 * WeightFunction.cpp
 *
 *  Created on: Dec 2, 2010
 *      Author: bert
 */

#include "WeightFunction.h"

WeightFunction::WeightFunction() {
}

WeightFunction::~WeightFunction() {
}

double WeightFunction::getWeight(double *x, double *y, int d) {
	return 0.0;
}


