/*
C version of belief propagation b-matching.

Bert Huang (2006)
Send comments and questions to bert at cs.columbia.edu

Please contact Bert if you use this code for anything other than 
evaluation. 
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#define NEG_INF -9999
#define MAX_ITER 10000
#define CONVERGENCE_INSURANCE 20

typedef struct node_t_struct {
  int id;
  int neighborhood; //number of neighbors (not counting itself)
  struct node_t_struct **neighbors; //vector of pointers to neighbors
  double *message; //vector of messages from this node to all other nodes
  double *phi;   //potential
  int *beliefs; //current top b node ids
} node_t;

node_t * initNode(int n, int id, int b, int total)
{
  int i;
  node_t *node;
  node = (node_t *)malloc(sizeof(node_t));
  node->id = id;
  node->neighborhood = n;
  node->message = (double*)malloc(total*sizeof(double));
  node->phi = (double*)malloc(n*sizeof(double));
  node->neighbors = (node_t**)malloc(n*sizeof(node_t*));
  
  for (i=0; i<total; i++) {
    node->message[i]=1;		
  }
  for (i=0; i<n; i++)
    node->phi[i]=1;
	
  node->beliefs = (int*) malloc(b*sizeof(int));
  for (i=0; i<b; i++) {
    node->beliefs[i] = i;
  }
	
  return node;
}

void freeNode(node_t *node)
{
  free(node->message);
  free(node->beliefs);
  free(node->phi);
  free(node->neighbors);
}

void updateMessages(node_t *node, int b)
     /*updates the messages stored in the given node
       by using messages from neighbors in opposite*/
{
  double *workvec;
  int *topvals, n=node->neighborhood, i ,j, minind, bth, counter;
	
  workvec = (double*)malloc(n*sizeof(double));
  topvals = (int*)malloc((b+1)*sizeof(int));
  
  //compute work vector
  for (i=0; i<n; i++) {
    workvec[i] = node->phi[i]*node->neighbors[i]->message[node->id];
  }
	
  //initialize topvals to be the first b+1 indexes
  minind=0; bth=0;
  for (i=0; i<b+1; i++) {
    topvals[i]=i;
    if (workvec[topvals[i]]<workvec[topvals[minind]])
      minind=i;
  }
	
  //find true topvals and true minind
  for (i=b+1; i<n; i++) {
    if (workvec[i]>workvec[topvals[minind]]) {
      topvals[minind] = i;
      for (j=0; j<b+1; j++) {
	if (workvec[topvals[j]]<workvec[topvals[minind]])
	  minind=j;
      }
    }
  }
	
  //find bth entry
  if (minind==0)
    bth=1;
  for (i=0; i<b+1; i++) {
    if (i!=minind && workvec[topvals[i]]<workvec[topvals[bth]])
      bth = i;
  }
	
  //update messages
  for (i=0; i<n; i++) {
    if (workvec[i]>=workvec[topvals[bth]])
      node->message[node->neighbors[i]->id]=node->phi[i]/workvec[topvals[minind]];
    else
      node->message[node->neighbors[i]->id]=node->phi[i]/workvec[topvals[bth]];
  }
  
  //update beliefs
  counter=0;
  for (i=0; i<b+1; i++) {
    if (i!=minind) {
      node->beliefs[counter++] = node->neighbors[topvals[i]]->id;
    }
  }
	
  free(workvec);
  free(topvals);
}

int permCheck(node_t **nodes, int**P, int n, int b) 
     /*checks if there is a valid bmatching in the beliefs*/
{
  int ret=1, i, j, *counters;
	
  counters = (int*)malloc(n*sizeof(int));
  
  for (i=0; i<n; i++)
    counters[i]=0;
	
  for (i=0; i<n; i++) {
    for (j=0; j<b; j++) {
      P[i][j]=nodes[i]->beliefs[j];
      counters[nodes[i]->beliefs[j]]++;
    }
  }
	
  for (i=0; i<n; i++) 
    if (counters[i]!=b)
      ret=0;
	
  free(counters);
  return ret;
}

void readMatrix(double** W, char* filename, int n)
     /*reads a matrix in from an ascii text file*/
{
  int i,j;
  FILE *fin;
	
	
  fin = fopen(filename, "r");
  for (i=0; i<n; i++) {
    for (j=0; j<n; j++) {
      fscanf(fin, "%lf", &W[i][j]);
    }
  }
  fclose(fin);
}

void writeOut(int **P, char*filename, int n, int b)
     /*writes a matrix out to an ascii text file*/
{
  int i,j;
  FILE *fout;
	
  fout = fopen(filename, "wt");
  for (i=0; i<n; i++) {
    for (j=0; j<b; j++) {
      fprintf(fout, "%d ", P[i][j]);
    }
    fprintf(fout, "\n");
  }
  fclose(fout);
  
}

int main(int argc, char**argv)
{
  //assume n objects, nxn matrix
  double **W; //fsum
  int i,j,n, sum, counter, converged=CONVERGENCE_INSURANCE, iters=0, links=0, b, lcount;
  int **P;
  node_t **alpha, **beta;
  if (argc==5) {
    srand(time(NULL));
    n = atoi(argv[2]);
    b = atoi(argv[3]);
    W = (double**)malloc(n*sizeof(double*));
    P = (int**)malloc(n*sizeof(int*));
    for (i=0; i<n; i++) {
      P[i] = (int*)malloc(b*sizeof(int));
      W[i] = (double*)malloc(n*sizeof(double));
    }
    readMatrix(W,argv[1], n);
		
    /*********************************
			allocate and initialize
    *************************************/
		
    alpha = (node_t**)malloc(n*sizeof(node_t*));
    beta = (node_t**)malloc(n*sizeof(node_t*));
    
    for (i=0; i<n; i++) { //initialize nodes
      sum=0;
      for (j=0; j<n; j++) {
	if (W[i][j]>NEG_INF) { //if negative weight, cut link
	  sum++;
	  lcount++;
	}
      }
      alpha[i] = initNode(sum,i,b,n);
    }

    for (i=0; i<n; i++) { //initialize nodes
      sum=0;
      for (j=0; j<n; j++) {
	if (W[j][i]>NEG_INF) { //if negative weight, cut link
	  sum++;
	  lcount++;
	}
      }
      beta[i] = initNode(sum,i,b,n);
    }
		
    //now connect the nodes
		
    for (i=0; i<n; i++) {
      counter = 0;
      for (j=0; j<n; j++) {
	if (W[i][j]>NEG_INF) {
	  alpha[i]->neighbors[counter] = beta[j];
	  alpha[i]->phi[counter] = exp(W[i][j]);
	  counter++;
	  links++;
	}
      }
    }
    for (i=0; i<n; i++) {
      counter = 0;
      for (j=0; j<n; j++) {
	if (W[j][i]>NEG_INF) {
	  beta[i]->neighbors[counter] = alpha[j];
	  beta[i]->phi[counter] = exp(W[j][i]);
	  counter++;
	  links++;
	}
      }
    }

    //printf("Graph allocated, %d nodes, %d links, %.2f connectivity\n", n, links, 100*(double)links/(double)(n*n));
    
    /*********************************************
			belief propagation
    *********************************************/
    while(converged>0) {

      for (i=0; i<n; i++) {
	updateMessages(beta[i],b);
      }
      for (i=0; i<n; i++) {
	updateMessages(alpha[i],b);
      }
			
      //printf("message update successful\n");
      //check for convergence
      converged -= permCheck(alpha,P,n,b);
      
      //printf("permcheck successful\n");
			
      if (++iters>MAX_ITER) {
	printf("Reached maximum iterations without converging\n");
	converged=0;
      }			
    }
    /********************************************
			output answer
    *********************************************/
		
    writeOut(P,argv[4],n,b);
		
    //clean up
    for (i=0; i<n; i++) {
      free(W[i]);
      free(P[i]);
    }
    free(alpha);
    free(beta);
    free(P);
    free(W);
  } else {
    printf("Usage: ./cbpbm <input file> <size> <b> <output file>\n");
  }
	
  return 0;
}

