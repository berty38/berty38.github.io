function [P,t] = cbpbm(W,b);

%[P,t] = cbpbm(W,b);
%W = weight matrix
%b = degree of b-matching
%P adjacency matrix for b-matching
%t = running time

num = round(rand*100000);

fname = ['tmp_bpweights' num2str(num)];

eval(['save ' fname ' -ascii W']);

command = ['./cbpbm ' fname ' ' num2str(size(W,1)) ' ' num2str(b) ' ' fname 'out.txt'];
tic;
system(command);

t=toc;

Pout=load([fname 'out.txt']);
system(['rm ' fname '*']);

P = zeros(size(W));

for i=1:size(P,1)
     P(i,1+Pout(i,:))=1;
end

